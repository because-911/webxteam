const WarnsReasonData = {
    //Причины предупреждений.
    UserId: {
      type: Mongo.Types.String,
      default: undefined
    },
    ModerID: {
      type: Mongo.Types.String,
      default: undefined
    },
    Warn: {
      //Какое предупреждение.
      type: Mongo.Types.Number,
      default: undefined
    },
    Time: {
      //Когда было сделано предупреждение.
      type: Mongo.Types.Number,
      default: undefined
    },
    Reason: {
      //Причина.
      type: Mongo.Types.String,
      default: undefined
    }
  };
  global.MongoDB.addModel("WarnsReason", WarnsReasonData);
const BotData = {
    id: { type: Mongo.Types.Number, default: undefined },
    TimeStatus: { type: Mongo.Types.String, default: undefined }
  };
  MongoDB.addModel("bot", BotData);
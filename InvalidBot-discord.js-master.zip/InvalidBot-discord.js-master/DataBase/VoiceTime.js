const VoiceTimeData = {
  UserId: { type: Mongo.Types.String, default: undefined },
  time: { type: Mongo.Types.String, default: 0 }
};
global.MongoDB.addModel("VoiceTime", VoiceTimeData);

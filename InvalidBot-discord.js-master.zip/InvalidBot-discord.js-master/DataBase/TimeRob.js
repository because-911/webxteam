const TimeRobData = {
    UserId: {
      type: Mongo.Types.String,
      default: undefined
    },
    time: {
      type: Mongo.Types.Number,
      default: undefined
    }
  };
  global.MongoDB.addModel("timerob", TimeRobData);
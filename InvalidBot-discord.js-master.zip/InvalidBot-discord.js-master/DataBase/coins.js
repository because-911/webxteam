const CoinsData = {
    UserId: {
      type: Mongo.Types.String,
      default: undefined
    },
    coins: {
      type: Mongo.Types.Number,
      default: 0
    }
  };
  global.MongoDB.addModel("coins", CoinsData);
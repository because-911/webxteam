const MessageData = {
    UserId: { type: Mongo.Types.String, default: undefined },
    message: { type: Mongo.Types.Number, default: 0 }
  };
  global.MongoDB.addModel("message", MessageData);
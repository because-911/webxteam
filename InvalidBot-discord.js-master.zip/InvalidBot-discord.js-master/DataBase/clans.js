const ClanData = {
    OwnerId: {
      type: Mongo.Types.String,
      default: undefined
    },
    Name: {
      type: Mongo.Types.String,
      default: "Не указано."
    },
    Info: {
      type: Mongo.Types.String,
      default: "Не указано."
    },
    Members: {
      type: Mongo.Types.Array,
      default: []
    },
    Money: {
      type: Mongo.Types.String,
      default: 0
    },
    Glasses: {
      type: Mongo.Types.String,
      default: 0
    }
  };
  global.MongoDB.addModel("clans", ClanData);
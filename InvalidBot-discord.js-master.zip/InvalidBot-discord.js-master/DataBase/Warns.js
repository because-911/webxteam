const WarnsData = {
    //Предупреждения участника.
    UserId: {
      type: Mongo.Types.String,
      default: undefined
    },
    Warns: {
      //Количество предупреждений.
      type: Mongo.Types.String,
      default: 0
    }
  };
  global.MongoDB.addModel("Warns", WarnsData);
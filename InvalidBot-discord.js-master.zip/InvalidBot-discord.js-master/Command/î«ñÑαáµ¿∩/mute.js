const { RichEmbed } = require("discord.js");
const { RoleMuteName, channelLogs } = config;
module.exports.run = async (client, message, args) => {
  const collection = db.collection("mutes");
  function uts(UT, one, two, five) {
    if (`${UT}`.split("").reverse()[1] === "1") return `${UT} ${five}`;
    if (`${UT}`.split("").reverse()[0] === "1") return `${UT} ${one}`;
    if (
      +`${UT}`.split("").reverse()[0] >= 2 &&
      +`${UT}`.split("").reverse()[0] <= 4
    )
      return `${UT} ${two}`;
    return `${UT} ${five}`; //Формат времени.
  }
  const rUser = message.guild.member(
    //Переменная которая ловит и ID юзера и пинг.
    message.mentions.users.first() || message.guild.members.get(args[0])
  );
  let Time = args[1];
  var reason = args.slice(2).join(" ");
  var role = message.guild.roles.find("name", RoleMuteName); //Мут роль.
  if (
    !["MANAGE_MESSAGES", "MANAGE_ROLES"].some(i =>
      message.member.hasPermission(i)
    )
  )
    return message.channel.send(
      new RichEmbed()
        .setColor("RED")
        .setDescription(
          "У вас должны быть права на удаление сообщений или выдачи ролей!"
        )
        .setFooter(client.user.username, client.user.displayAvatarURL)
        .setTimestamp()
    );
  if (!role) {
    message.channel.send(
      new RichEmbed().setColor(colors).setAuthor("Роль создана.")
    );
    await message.guild.createRole({
      //Создание роли.
      name: RoleMuteName
    });
    message.guild.channels.forEach(async (channel, id) => {
      //Убираем права у роли.
      await channel.overwritePermissions(role, {
        SEND_MESSAGES: false,
        ADD_REACTIONS: false
      });
    });
  }
  if (!args[0])
    return message.channel.send(
      new RichEmbed()
        .setColor("RED")
        .setDescription(`Укажите участника!`)
        .setFooter(message.author.username, message.author.displayAvatarURL)
        .setTimestamp()
    );
  if (!rUser)
    return message.channel.send(
      new RichEmbed()
        .setColor("RED")
        .setDescription(`Не найден участник!`)
        .setFooter(message.author.username, message.author.displayAvatarURL)
        .setTimestamp()
    );
  if (rUser.id === message.author.id)
    return message.channel.send(
      new RichEmbed()
        .setColor("RED")
        .setDescription(`Нельзя замутить самого себя!`)
        .setFooter(message.author.username, message.author.displayAvatarURL)
        .setTimestamp()
    );
  if (rUser.id == message.guild.owner.id)
    return message.channel.send(
      new RichEmbed()
        .setColor("RED")
        .setDescription(`Нельзя замутить создателя сервера!`)
        .setFooter(message.author.username, message.author.displayAvatarURL)
        .setTimestamp()
    );
  if (rUser.hasPermission("ADMINISTRATOR"))
    return message.channel.send(
      new RichEmbed()
        .setColor("RED")
        .setTimestamp()
        .setDescription("Нельзя замутить Администратора!")
        .setFooter(message.author.username, message.author.displayAvatarURL)
    );
  if (!Time)
    return message.channel.send(
      new RichEmbed()
        .setColor("RED")
        .setDescription(`Укажите время!`)
        .setFooter(`Пример использования команды: .mute @Участник 5 Спам`)
    );
  if (!reason)
    return message.channel.send(
      new RichEmbed()
        .setColor("RED")
        .setDescription(`Укажите причину!`)
        .setFooter(message.author.username, message.author.displayAvatarURL)
        .setTimestamp()
    );
  let one = "минуту";
  let two = "минуты";
  let five = "минут";
  let embed = new RichEmbed()
    .setColor(colors)
    .setTimestamp()
    .setAuthor("Mute")
    .addField(`Кто выдал:`, message.author, true)
    .addField(`Кому:`, rUser, true)
    .addField(`Причина:`, reason, true)
    .addField(`Время:`, uts(Time, one, two, five), true)
    .setFooter(client.user.username, client.user.displayAvatarURL);
  message.channel.send(embed);
  client.channels.get(channelLogs).send(embed);
  let a = Time * 60;
  let mute = [
    {
      UserId: rUser.id,
      GuildId: message.guild.id,
      Time: parseInt(Date.now() + a * 1000)
    }
  ];
  collection.insertMany(mute);
  rUser.addRole(role); //Выдача роли.
};
module.exports.command = {
  name: "mute"
};

const { RichEmbed } = require("discord.js");
const { RoleRestartID, botOwner } = require("../../botconfig.json");
module.exports.run = async (client, message, args) => {
  let roleOwner = message.guild.roles.find("id", RoleRestartID);
  function code() {
    message.channel.send("Выполняется перезагрузка...").then(msg =>
      msg.edit(
        require("child_process")
          .execSync("refresh")
          .toString("utf8") + ""
      )
    );
  }
  if (config.BotOwnersID.some(e => message.author.id == e)) return code();
  if (!message.member.roles.has(roleOwner.id))
    return message.channel.send(
      new RichEmbed()
        .setColor("RED")
        .setTimestamp()
        .setFooter(message.author.username, message.author.displayAvatarURL)
        .setDescription(`У вас недостаточно прав для выполнения команды!`)
    );
  code();
};
module.exports.command = {
  name: "botr",
  DM: true
};

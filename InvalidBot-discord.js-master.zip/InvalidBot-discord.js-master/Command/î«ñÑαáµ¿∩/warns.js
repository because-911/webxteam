const { RichEmbed } = require("discord.js");
let vremya = strftime.timezone(180);
module.exports.run = async (client, message, args) => {
  let rUser = message.guild.member(
    message.mentions.users.first() ||
      message.guild.members.get(args[0]) ||
      message.author
  );
  const collection = db.collection("warnsreason");
  collection.find({ UserId: rUser.id }).toArray(async function(err, results) {
    if (results[0] == undefined)
      return message.channel.send(
        new Discord.RichEmbed()
          .setColor(colors)
          .setDescription(
            `У ${rUser.id == message.author.id ? "вас" : rUser} 0 варнов.`
          )
          .setTimestamp()
          .setFooter(client.user.username, client.user.displayAvatarURL)
      );
    await MongoDB.Warns._toCollection();
    let res = MongoDB.Warns.findOne({
      UserId: rUser.id
    });
    let warn = res.Warns;
    let embed = new Discord.RichEmbed()
      .setColor(colors)
      .setFooter(rUser.user.username, rUser.user.displayAvatarURL)
      .setDescription(
        `У ${
          rUser.id == message.author.id ? "вас" : `${rUser}`
        }: ${warn} выговоров.\n${results
          .map(
            i =>
              `${vremya("%e.%m.%Y в %H:%M", new Date(i.Time))} | ${
                i.Reason
              } | <@${i.ModerID}>`
          )
          .join("\n") || "Техническая неполадка."}`
      )
      .setTimestamp();
    message.channel.send(embed);
  });
};
module.exports.command = {
  name: "warns"
};

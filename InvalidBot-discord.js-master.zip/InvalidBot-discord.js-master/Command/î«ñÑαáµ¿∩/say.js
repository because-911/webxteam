const { RichEmbed } = require("discord.js");
module.exports.run = async (client, message, args) => {
  let say = args.join(" "); //То, что написал игрок
  message.delete();
  message.channel.send(new RichEmbed().setColor("#0000CD").setDescription(say));
};
module.exports.command = {
  name: "say",
  owner: true
};

const { channelLogs } = config;
const { RichEmbed } = require("discord.js");
module.exports.run = async (client, message, args) => {
  try {
    let roleOwner = message.guild.roles.find("id", "618495942148227093");
    let roleSБОТ = message.guild.roles.find("id", "620996430231764992");
    let roleS_Staff = message.guild.roles.find("id", "618495582540922920");
    let roleSAdmin = message.guild.roles.find("id", "618489300060864512");
    let roleSModerator = message.guild.roles.find("id", "618489382600572930");
    let roleSHelper = message.guild.roles.find("id", "618489580361875498");
    let roleS = message.guild.roles.find("id", "622329462650044417"); //ID роли "warn"
    const rUser = message.guild.member(
      //Переменная которая ловит и ID юзера и пинг.
      message.mentions.users.first() || message.guild.members.get(args[0])
    );
    const reason = args.slice(1).join(" ");
    if (!message.guild.me.permissions.has("MANAGE_ROLES"))
      return message.channel.send(
        new RichEmbed()
          .setColor("RED")
          .setDescription(`Ошибка, у меня нет прав управлять ролями!`)
          .setTimestamp()
      );
    if (!roleS)
      return message.channel.send(
        new RichEmbed()
          .setColor("RED")
          .setDescription(`Ошибка, роль "warn" не найдена!`)
          .setTimestamp()
      );
    async function code() {
      if (!rUser)
        return message.channel.send(
          new RichEmbed()
            .setColor("RED")
            .setDescription(`Укажите игрока или его ID!`)
            .setTimestamp()
        );
      if (rUser.id === message.author.id)
        return message.channel.send(
          new RichEmbed()
            .setColor("RED")
            .setDescription(`Вы не можете выдать себе варн!`)
            .setTimestamp()
        );
      if (rUser.id === message.guild.owner.id)
        return message.channel.send(
          new RichEmbed()
            .setColor("RED")
            .setDescription(`Вы не можете выдать Создателю варн!`)
            .setTimestamp()
        );
      message.delete();
      message.channel.send(
        new RichEmbed()
          .setColor(colors)
          .addField("Выдано:", rUser, true)
          .addField("Выдал:", message.author, true)
          .addField("Причина:", !reason ? "Не указана." : reason, true)
      );
      client.channels.get(channelLogs).send(
        new RichEmbed()
          .addField("Выдано:", rUser, true)
          .addField("Выдал:", message.author, true)
          .addField("Причина:", !reason ? "Не указана." : reason, true)
          .setTimestamp()
          .setColor("RED")
          .setAuthor("WARN")
      );
      if (!rUser.roles.has(roleS.id)) rUser.addRole(roleS);
      await MongoDB.Warns._toCollection();
      let res = MongoDB.Warns.findOne({
        UserId: rUser.id
      });
      let warn = res.Warns;
      if (!res.UserId) {
        await MongoDB.Warns.insertOne({
          UserId: rUser.id,
          Warns: 1
        });
      } else {
        await MongoDB.Warns.updateOne(
          { UserId: rUser.id },
          { Warns: parseInt(warn) + parseInt(1) }
        );
      }
      await MongoDB.WarnsReason._toCollection();
      MongoDB.WarnsReason.insertOne({
        UserId: rUser.id,
        ModerID: message.author.id,
        Warn: parseInt(warn) + parseInt(1),
        Time: Date.now(),
        Reason: !reason ? "Не указана" : reason
      });
    }
    if (message.member.permissions.has("ADMINISTRATOR")) return code();
    if (
      [
        roleOwner.id,
        roleSБОТ.id,
        roleS_Staff.id,
        roleSAdmin.id,
        roleSAdmin.id,
        roleSModerator.id,
        roleSHelper.id
      ].some(i => message.member.roles.has(i))
    )
      return code();
    message.channel.send(
      new RichEmbed()
        .setColor("RED")
        .setDescription(`У вас недостаточно прав!`)
        .setTimestamp()
    );
  } catch (err) {
    //В случае ошибки, бот отправит сообщение в определённый канал.
    message.channel.send(
      new RichEmbed()
        .setColor("RED")
        .setTimestamp()
        .setFooter("Обратитесь к создателем бота для устранения проблемы.")
        .setDescription(
          `Произошла ошибка при выполнения команды! \`${err.name}\``
        )
    );
    client.channels.get("621354439034404874").send(
      new RichEmbed()
        .setColor("RED")
        .addField(
          `Произошла ошибка при выполнении команды: \`warn\`\nВыполнил команду: ${message.author} (\`${message.author.id}\`)\n[Контент:](https://discordapp.com/channels/${message.guild.id}/${message.channel.id}/${message.id}) ${message.content}`,
          err
        )
        .setTimestamp()
        .setFooter("Ошибка...")
    );
  }
};
module.exports.command = {
  name: "warn"
};

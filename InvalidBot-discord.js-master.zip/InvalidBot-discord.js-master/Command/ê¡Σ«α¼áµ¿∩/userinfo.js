const { RichEmbed } = require("discord.js");
module.exports.run = async (client, message, args) => {
  function uts(UT, one, two, five) {
    if (`${UT}`.split("").reverse()[1] === "1") return `${UT} ${five}`;
    if (`${UT}`.split("").reverse()[0] === "1") return `${UT} ${one}`;
    if (
      +`${UT}`.split("").reverse()[0] >= 2 &&
      +`${UT}`.split("").reverse()[0] <= 4
    )
      return `${UT} ${two}`;
    return `${UT} ${five}`; //Формат времени.
  }
  const rUser = message.guild.member(
    //Переменная которая ловит и ID юзера и пинг.
    message.mentions.users.first() ||
      message.guild.members.get(args[0]) ||
      message.author
  );
  await MongoDB.coins._toCollection();
  let resCoins = MongoDB.coins.findOne({ UserId: rUser.id });
  await MongoDB.message._toCollection();
  let resMessage = MongoDB.message.findOne({ UserId: rUser.id });
  await MongoDB.VoiceTime._toCollection();
  let resTime = MongoDB.VoiceTime.findOne({ UserId: rUser.id });
  let a = `**Информация об игроке ${rUser}**


  **🚀Ник на сервере:** 
  ${rUser.user.username}

  **💎Роли на сервере: **
   ${rUser.roles.size - 1}

  **💿Сообщений отправлено:** 
    ${resMessage.message}

  **💵Кол-во серверной валюты:**
    ${resCoins.coins}

  **🆔ID:**
  ${rUser.id}

  **🕧Голосовой онлайн:**
  ${uts(new Date(resTime.time).getHours(), "час.", "часа.", "часов.")}`;
  message.channel.send(
    new RichEmbed()
      .setColor(colors)
      .setDescription(a)
      .setThumbnail(rUser.user.displayAvatarURL) //Аватарка юзера.
  );
};
module.exports.command = {
  name: "userinfo"
};

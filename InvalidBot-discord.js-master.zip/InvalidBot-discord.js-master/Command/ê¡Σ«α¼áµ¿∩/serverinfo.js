const { RichEmbed } = require("discord.js");
const { RoleModeratorID, RoleAdminID } = config;
module.exports.run = async (client, message, args) => {
  let roleSModerator = message.guild.roles.find(r => r.id === RoleModeratorID);
  let roleSAdmin = message.guild.roles.find(r => r.id === RoleAdminID);
  let a = `👨**Игроков на сервере: **
${message.guild.memberCount -
  message.guild.members.filter(mem => mem.user.bot === true).size}

🤖**Ботов на сервере:**
${message.guild.members.filter(mem => mem.user.bot === true).size}

💎**Ролей на сервере: **
${message.guild.roles.size}

🇷🇺**Регион сервера:**
${message.guild.region}

💦**Овнеры сервера:**
<@403966149152210944>, <@601265391519662080>

🚨**Модераторов на сервере:**
${roleSModerator.members.size}

👮**Администраторов на сервере:** 
${roleSAdmin.members.size}`;
  message.channel.send(
    new RichEmbed()
      .setColor(colors)
      .addField(`**Информация сервера**`, a)
      .setTimestamp()
      .setThumbnail(message.guild.iconURL)
  );
};
module.exports.command = {
  name: "serverinfo"
};

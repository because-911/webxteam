const { RichEmbed } = require("discord.js");
const colors = "#0000CD";
module.exports.run = async (client, message, args) => {
  const collection = db.collection("message");
  collection
    .find({})
    .sort({ message: -1 })
    .toArray()
    .then(async res => {
      let i = 0;
      let text = ``
      await res.map(u => {
        if (!message.guild.member(u.UserId)) return;
        if (i == 8) return;
        i++;
        text += `[ ${i} ] Имя : <@${u.UserId}>\nID : ${u.UserId}\nКол-во 📨: ${u.message}\n\n`;
      });
      message.channel.send(
        new RichEmbed()
          .setColor(colors)
          .setAuthor("Топ отправленных сообщений.")
          .setDescription(text)
      );
    });
};
module.exports.command = {
  name: "topchat",
  DM: true
};

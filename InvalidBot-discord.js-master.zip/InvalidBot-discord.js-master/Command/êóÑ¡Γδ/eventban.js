const { RichEmbed } = require("discord.js");
const { RoleEventID, RoleEventBannedID } = require("../../botconfig.json");
module.exports.run = async (client, message, args) => {
  const rUser = message.guild.member(
    //Переменная которая ловит и ID юзера и пинг.
    message.mentions.users.first() || message.guild.members.get(args[0])
  );
  if (!RoleEventID.some(i => message.member.roles.has(i)))
    return message.channel.send(
      new RichEmbed()
        .setColor("RED")
        .setTimestamp()
        .setFooter(message.author.username, message.author.displayAvatarURL)
        .setDescription(`У вас недостаточно прав для выполнения команды!`)
    );
  var role = message.guild.roles.find("id", RoleEventBannedID); //Мут роль.
  if (!rUser)
    return message.channel.send(
      new RichEmbed()
        .setColor("RED")
        .setDescription(`Укажите участника!`)
        .setFooter(message.author.username, message.author.displayAvatarURL)
        .setTimestamp()
    );
  if (rUser.id == message.author.id)
    return message.channel.send(
      new RichEmbed()
        .setColor("RED")
        .setDescription(`Нельзя выдать роль самому себе!`)
        .setFooter(message.author.username, message.author.displayAvatarURL)
        .setTimestamp()
    );
  if (rUser.id == message.guild.owner.id)
    return message.channel.send(
      new RichEmbed()
        .setColor("RED")
        .setDescription(`Нельзя выдать роль создателю сервера!`)
        .setFooter(message.author.username, message.author.displayAvatarURL)
        .setTimestamp()
    );
  if (rUser.hasPermission("ADMINISTRATOR"))
    return message.channel.send(
      new RichEmbed()
        .setColor("RED")
        .setTimestamp()
        .setDescription("Нельзя выдать роль Администратору!")
        .setFooter(message.author.username, message.author.displayAvatarURL)
    );
  message.channel.send(
    new RichEmbed()
      .setColor(colors)
      .setTimestamp()
      .setDescription(
        `Вы успешно выдали роль <@&${RoleEventBannedID}> игроку ${rUser}.`
      )
      .setFooter(message.author.username, message.author.displayAvatarURL)
  );
  rUser.addRole(role);
};
module.exports.command = {
  name: "eventban"
};

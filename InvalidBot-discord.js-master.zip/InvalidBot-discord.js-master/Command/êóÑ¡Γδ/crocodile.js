const { RichEmbed } = require("discord.js");
const { RoleEventID } = require("../../botconfig.json");
module.exports.run = async (client, message, args) => {
  if (!RoleEventID.some(i => message.member.roles.has(i)))
    return message.channel.send(
      new RichEmbed()
        .setColor("RED")
        .setTimestamp()
        .setFooter(message.author.username, message.author.displayAvatarURL)
        .setDescription(`У вас недостаточно прав для выполнения команды!`)
    );
  if (!args[0])
    return message.channel.send(
      new RichEmbed()
        .setColor("RED")
        .setDescription(`Укажите время проведения!`)
        .setFooter(message.author.username, message.author.displayAvatarURL)
        .setTimestamp()
    );
  let a = `\`\`\`Игра Крокодил отлично помогает весело провести время большой группе ребят, развивает воображение, догадливость и артистизм.\`\`\`

**Награды :**
\`\`\`
1 место - 100 коинов.

2 место - 50 коинов.

3 место - 30 коинов.

За участие - 10 коинов.

Время начала : ${args.join(" ")}
\`\`\`
Проводит : ${message.author}`;
  message.channel.send(
    new RichEmbed()
      .setAuthor("Мероприятие")
      .setImage(
        "https://cdn.discordapp.com/attachments/621354439034404874/649796339252592651/PicsArt_11-29-05.12.46_resize_15.png"
      )
      .setColor(colors)
      .setThumbnail(message.guild.iconURL)
      .setDescription(a)
  );
};
module.exports.command = {
  name: "crocodile"
};

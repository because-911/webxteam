const { RichEmbed } = require("discord.js");
const { RoleEventID } = require("../../botconfig.json");
module.exports.run = async (client, message, args) => {
  if (!RoleEventID.some(i => message.member.roles.has(i)))
    return message.channel.send(
      new RichEmbed()
        .setColor("RED")
        .setTimestamp()
        .setFooter(message.author.username, message.author.displayAvatarURL)
        .setDescription(`У вас недостаточно прав для выполнения команды!`)
    );
  if (!args[0])
    return message.channel.send(
      new RichEmbed()
        .setColor("RED")
        .setDescription(`Укажите время проведения!`)
        .setFooter(message.author.username, message.author.displayAvatarURL)
        .setTimestamp()
    );
  let a = `\`\`\`«Шляпа» — игра для большой компании, во время которой игроки по очереди пытаются объяснить,  какое-то слово, а сокомандник  старается это слово угадать. В случае успеха и отгадавший слово игрок, и загадавший его получают победные очки.\`\`\`


**Награды :**
\`\`\`
1 место - 200 коинов.

2 место - 110 коинов. 

3 место - 60 коинов.

За участие - 30 коинов.

Время начала : ${args.join(" ")}
\`\`\`
Проводит : ${message.author}`;
  message.channel.send(
    new RichEmbed()
      .setAuthor("Мероприятие")
      .setColor(colors)
      .setImage(
        "https://cdn.discordapp.com/attachments/621354439034404874/649796339252592651/PicsArt_11-29-05.12.46_resize_15.png"
      )
      .setDescription(a)
      .setThumbnail(message.guild.iconURL)
  );
};
module.exports.command = {
  name: "hat"
};

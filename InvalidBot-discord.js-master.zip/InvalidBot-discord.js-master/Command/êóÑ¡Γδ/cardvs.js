const { RichEmbed } = require("discord.js");
const { RoleEventID } = require("../../botconfig.json");
module.exports.run = async (client, message, args) => {
  if (!RoleEventID.some(i => message.member.roles.has(i)))
    return message.channel.send(
      new RichEmbed()
        .setColor("RED")
        .setTimestamp()
        .setFooter(message.author.username, message.author.displayAvatarURL)
        .setDescription(`У вас недостаточно прав для выполнения команды!`)
    );
  if (!args[0])
    return message.channel.send(
      new RichEmbed()
        .setColor("RED")
        .setDescription(`Укажите время проведения!`)
        .setFooter(message.author.username, message.author.displayAvatarURL)
        .setTimestamp()
    );
  let a = `\`\`\`«Карты против всех» - это партийная игра, в которой игроки заполняют пустые слова, используя слова или фразы, которые обычно считаются оскорбительными, рискованными или политически некорректными, напечатанными на игральных картах.\`\`\`

**Награды :**
\`\`\`
1 место - 150 коинов.

2 место - 90 коинов. 

3 место - 40 коинов.

За участие - 20 коинов.

Время начала : ${args.join(" ")}
\`\`\`
Проводит : ${message.author}`;
  message.channel.send(
    new RichEmbed()
      .setAuthor("Мероприятие")
      .setColor(colors)
      .setThumbnail(message.guild.iconURL)
      .setImage(
        "https://cdn.discordapp.com/attachments/621354439034404874/649796339252592651/PicsArt_11-29-05.12.46_resize_15.png"
      )
      .setDescription(a)
  );
};
module.exports.command = {
  name: "cardvs"
};

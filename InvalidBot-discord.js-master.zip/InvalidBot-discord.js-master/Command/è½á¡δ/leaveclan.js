const { RichEmbed } = require("discord.js");
module.exports.run = async (client, message, args) => {
  function arrDelete(arr, num) {
    if (num == 0) {
      arr.shift();
      return arr;
    }
    arr.splice(num, num);
    return arr;
  }
  await MongoDB.clans._toCollection();
  let d;
  const collection = db.collection("clans");
  collection.find({}).toArray(async function(err, results) {
    results.map(i => {
      i.Members.forEach(e => {
        if (e == message.author.id) d = i;
      });
    });
    if (!d)
      return message.channel.send(
        new RichEmbed()
          .setColor("RED")
          .setDescription(`Ну типа тебя нет в никаком клане!`)
          .setFooter(message.author.username, message.author.displayAvatarURL)
          .setTimestamp()
      );
    message.channel.send(
      new RichEmbed()
        .setColor(colors)
        .setDescription(`Вы успешно вышли с клана: \`${d.Name}\``)
        .setFooter(message.author.username, message.author.displayAvatarURL)
        .setTimestamp()
    );
    MongoDB.clans.updateOne(
      { OwnerId: d.OwnerId },
      { Members: arrDelete(d.Members, d.Members.indexOf(message.author.id)) }
    );
  });
};
module.exports.command = {
  name: "leaveclan"
};

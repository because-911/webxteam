const { RichEmbed } = require("discord.js");
module.exports.run = async (client, message, args) => {
  await MongoDB.clans._toCollection();
  if (!MongoDB.clans.hasOne({ OwnerId: message.author.id }))
    return message.channel.send(
      new RichEmbed()
        .setColor("RED")
        .setFooter(message.author.username, message.author.displayAvatarURL)
        .setTimestamp()
        .setDescription(`У тебя нет клана..`)
    );
  if (!args[0])
    return message.channel.send(
      new RichEmbed()
        .setColor("RED")
        .setFooter(message.author.username, message.author.displayAvatarURL)
        .setTimestamp()
        .setDescription(`Укажи описание клана.`)
    );
  message.channel.send(
    new RichEmbed()
      .setColor(colors)
      .setFooter(message.author.username, message.author.displayAvatarURL)
      .setTimestamp()
      .addField(`Ты успешно указал описание клана.`, args.join(" "))
  );
  MongoDB.clans.updateOne(
    { OwnerId: message.author.id },
    { Info: args.join(" ") }
  );
};
module.exports.command = {
  name: "descriptionclan"
};

const { RichEmbed } = require("discord.js");

module.exports.run = async (client, message, args) => {

  const collection = db.collection("clans");

  collection

    .find({})

    .sort({ Glasses: -1 })

    .toArray()

    .then(async res => {

      let i = 0;

      let text = ``;

      await res.map(u => {

        if (!message.guild.member(u.OwnerId)) return;

        if (i == 10) return;

        i++;

        text += `[ ${i} ] Лидер : <@${u.OwnerId}> | Название : ${u.Name}\nКол-во очков: ${u.Glasses}\n\n`;

      });

      message.channel.send(

        new RichEmbed()

          .setColor(colors)

          .setAuthor("Топ 10 кланов.")

          .setDescription(text)

      );

    });

};

module.exports.command = {

  name: "topclans",

  DM: true

};
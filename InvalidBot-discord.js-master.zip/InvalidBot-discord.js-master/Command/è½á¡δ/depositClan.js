const { RichEmbed } = require("discord.js");
module.exports.run = async (client, message, args) => {
  await MongoDB.coins._toCollection();
  await MongoDB.clans._toCollection();
  let dataClan;
  const collection = db.collection("clans");
  collection.find({}).toArray(async function(err, results) {
    results.map(i => {
      i.Members.forEach(e => {
        if (e == message.author.id) dataClan = i;
      });
    });
    if (
      !(
        MongoDB.clans.hasOne({
          OwnerId: dataClan ? dataClan.OwnerId : message.author.id
        }) || MongoDB.clans.hasOne({ OwnerId: message.author.id })
      )
    )
      return message.channel.send(
        new RichEmbed()
          .setColor("RED")
          .setDescription(`Ты не состоишь в каком-либо клане.`)
          .setFooter(message.author.username, message.author.displayAvatarURL)
          .setTimestamp()
      );
    let a = MongoDB.clans.findOne({ OwnerId: message.author.id });
    let b = MongoDB.clans.findOne({
      OwnerId: dataClan ? dataClan.OwnerId : message.author.id
    });
    dataClan = a.OwnerId ? a : b;
    let resCoins = MongoDB.coins.findOne({ UserId: message.author.id });
    if (!resCoins.coins)
      return message.channel.send(
        new RichEmbed()
          .setColor("RED")
          .setFooter(message.author.username, message.author.displayAvatarURL)
          .setTimestamp()
          .setDescription(`У вас 0 монет!`)
      );
    if (!args[0])
      return message.channel.send(
        new RichEmbed()
          .setColor("RED")
          .setFooter(message.author.username, message.author.displayAvatarURL)
          .setTimestamp()
          .setDescription(
            `Укажи количество монет, которые ты хочешь внести в клан.`
          )
      );
    if (isNaN(args[0]))
      return message.channel.send(
        new RichEmbed()
          .setColor("RED")
          .setFooter(message.author.username, message.author.displayAvatarURL)
          .setTimestamp()
          .setDescription(`Укажи валидное число.`)
      );
    if (args[0] < 1)
      return message.channel.send(
        new RichEmbed()
          .setColor("RED")
          .setFooter(message.author.username, message.author.displayAvatarURL)
          .setTimestamp()
          .setDescription(`Укажи значения больше нуля!`)
      );
    if (args[0] > parseInt(resCoins.coins))
      return message.channel.send(
        new RichEmbed()
          .setColor("RED")
          .setFooter(`Количество непнутов: ${resCoins.coins}`)
          .setTimestamp()
          .setDescription(`У тебя нет столько денег!`)
      );
    message.channel.send(
      new RichEmbed()
        .setColor(colors)
        .setFooter(
          `Остаток непнутов: ${parseInt(resCoins.coins) - parseInt(args[0])}`
        )
        .setTimestamp()
        .setDescription(
          `Вы успешно перевели ${parseInt(args[0])} непнутов на счёт клана \`${
            dataClan.Name
          }\``
        )
    );
    MongoDB.coins.updateOne(
      { UserId: message.author.id },
      { coins: parseInt(resCoins.coins) - parseInt(args[0]) }
    );
    MongoDB.clans.updateOne(dataClan, {
      Money: parseInt(dataClan.Money) + parseInt(args[0])
    });
  });
};
module.exports.command = {
  name: "depositclan"
};

const { RichEmbed } = require("discord.js");
module.exports.run = async (client, message, args) => {
  function arrDelete(arr, num) {
    if (num == 0) {
      arr.shift();
      return arr;
    }
    arr.splice(num, num);
    return arr;
  }
  let rUser = message.guild.member(
    //Переменная которая ловит и ID юзера и пинг.
    message.mentions.users.first() || message.guild.members.get(args[0])
  );
  const collection = db.collection("clans");
  await MongoDB.clans._toCollection();
  if (MongoDB.clans.hasOne({ OwnerId: message.author.id }))
    return message.channel.send(
      new RichEmbed()
        .setColor("RED")
        .setFooter(message.author.username, message.author.displayAvatarURL)
        .setTimestamp()
        .setDescription(`У тебя уже есть свой клан...`)
    );
  if (!args[0])
    return message.channel.send(
      new RichEmbed()
        .setColor("RED")
        .setFooter(message.author.username, message.author.displayAvatarURL)
        .setTimestamp()
        .setDescription(`Ну типа укажи клан.`)
    );
  if (
    !(
      MongoDB.clans.hasOne({ OwnerId: !rUser ? null : rUser.id }) ||
      MongoDB.clans.hasOne({ Name: args.join(" ") })
    )
  )
    return message.channel.send(
      new RichEmbed()
        .setColor("RED")
        .setDescription(`Ну типа такого клана нет!`)
        .setFooter(message.author.username, message.author.displayAvatarURL)
        .setTimestamp()
    );
  let a = MongoDB.clans.findOne({ Name: args.join(" ") });
  let b = MongoDB.clans.findOne({
    OwnerId: !rUser ? message.author.id : rUser.id
  });
  let res = a.OwnerId ? a : b;
  let d;
  collection.find({}).toArray(async function(err, results) {
    results.map(i => {
      i.Members.forEach(e => {
        if (e == message.author.id) d = i;
      });
    });
    if (res.Members.includes(message.author.id))
      return message.channel.send(
        new RichEmbed()
          .setColor("RED")
          .setTimestamp()
          .setFooter(message.author.username, message.author.displayAvatarURL)
          .setDescription(`Ну типа ты уже вступил в этот клан.`)
      );
    if (d)
      return message.channel
        .send(
          new RichEmbed()
            .setColor("RED")
            .setTimestamp()
            .setFooter(message.author.username, message.author.displayAvatarURL)
            .setDescription(
              `Вы уже вступлены в другой клан.\nЧтобы покинуть клан пропишите команду *.yes*.\nЧтобы остаться в клане пропишите команду *.no*.`
            )
        )
        .then(msg => {
          const collector = new Discord.MessageCollector(
            message.channel,
            m => m.author.id === message.author.id
          );
          collector.on("collect", msg2 => {
            if (msg2.content == ".yes") {
              msg.channel.send(
                new RichEmbed()
                  .setColor(colors)
                  .setTimestamp()
                  .setFooter(
                    message.author.username,
                    message.author.displayAvatarURL
                  )
                  .setDescription(
                    `Вы успешно вступили в клан \`${res.Name}\`, но вы покинули клан \`${d.Name}\``
                  )
              );
              MongoDB.clans.updateOne(
                { OwnerId: d.OwnerId },
                {
                  Members: arrDelete(
                    d.Members,
                    d.Members.indexOf(message.author.id)
                  )
                }
              );
              memberClanAdd();
              collector.stop();
            } else if (msg2.content.toLowerCase() == ".no") {
              msg.channel.send(
                new RichEmbed()
                  .setColor("RED")
                  .setTimestamp()
                  .setFooter(
                    message.author.username,
                    message.author.displayAvatarURL
                  )
                  .setDescription(`Вы отменили команду!`)
              );
              collector.stop();
            } else if (msg2.content.toLowerCase() == ".topclan") {
              msg.channel.send(
                new RichEmbed()
                  .setColor("RED")
                  .setTimestamp()
                  .setFooter(
                    message.author.username,
                    message.author.displayAvatarURL
                  )
                  .setDescription(`Вы отменили предыдущую команду!`)
              );
              collection.stop();
            } else return;
          });
        });
    function memberClanAdd() {
      res.Members.push(message.author.id);
      MongoDB.clans.updateOne(
        { OwnerId: res.OwnerId },
        { Members: res.Members }
      );
    }
    message.channel.send(
      new RichEmbed()
        .setColor(colors)
        .setTimestamp()
        .setFooter(message.author.username, message.author.displayAvatarURL)
        .setDescription(`Ну типа ты успешно вступил в клан: \`${res.Name}\``)
    );
    memberClanAdd();
  });
};
module.exports.command = {
  name: "joinclan"
};

const { RichEmbed } = require("discord.js");

module.exports.run = async (client, message, args) => {

  let rUser = message.guild.member(

    //Переменная которая ловит и ID юзера и пинг.

    message.mentions.users.first() || message.guild.members.get(args[0])

  );

  await MongoDB.clans._toCollection();

  let d;

  const collection = db.collection("clans");

  collection.find({}).toArray(async function(err, results) {

    results.map(i => {

      i.Members.forEach(e => {

        if (e == message.author.id) d = i;

      });

    });

    if (

      !(

        MongoDB.clans.hasOne({

          OwnerId: !rUser ? message.author.id : rUser.id

        }) ||

        MongoDB.clans.hasOne({ Name: args.join(" ") }) ||

        MongoDB.clans.hasOne({ OwnerId: d ? d.OwnerId : null })

      )

    )

      return message.channel.send(

        new RichEmbed()

          .setColor("RED")

          .setDescription(`Ну типа клана нет!`)

          .setFooter(message.author.username, message.author.displayAvatarURL)

          .setTimestamp()

      );

    let a = MongoDB.clans.findOne({ Name: args.join(" ") });

    let b = MongoDB.clans.findOne({

      OwnerId: !rUser ? message.author.id : rUser.id

    });

    let v = MongoDB.clans.findOne({ OwnerId: d ? d.OwnerId : null });

    let res = a.OwnerId ? a : b.OwnerId ? b : v;

    let text = `**Описание клана:**

\`\`\` ${res.Info}\`\`\`

**Количество участников:** ${res.Members.length}

\`\`\` ${res.Members.map(i =>

      client.users.get(i) ? client.users.get(i).username : "???"

    ).join(", ") || "Отсутствуют."}\`\`\`

**Деньги клана:** ${res.Money}

**Очки клана:** ${res.Glasses}`;

    message.channel.send(

      new RichEmbed()

        .setColor(colors)

        .setAuthor(res.Name)

        .setThumbnail(message.guild.iconURL)

        .setDescription(text)

    );

  });

};

module.exports.command = {

  name: "claninfo"

};


const { RichEmbed } = require("discord.js");
module.exports.run = async (client, message, args) => {
  await MongoDB.clans._toCollection();
  if (MongoDB.clans.hasOne({ OwnerId: message.author.id }))
    return message.channel.send(
      new RichEmbed()
        .setColor("RED")
        .setFooter(message.author.username, message.author.displayAvatarURL)
        .setTimestamp()
        .setDescription(`У тебя уже есть клан...`)
    );
  if (!args[0])
    return message.channel.send(
      new RichEmbed()
        .setColor("RED")
        .setFooter(message.author.username, message.author.displayAvatarURL)
        .setTimestamp()
        .setDescription(`Укажи название клана.`)
    );
  let d, b;
  const collection = db.collection("clans");
  collection.find({}).toArray(async function(err, results) {
    results.map(i => {
      if (i.Members == message.author.id) b = true;
      if (i.Name.toLowerCase() == args.join(" ").toLowerCase()) d = true;
    });
    if (b)
      return message.channel.send(
        new RichEmbed()
          .setColor("RED")
          .setFooter(message.author.username, message.author.displayAvatarURL)
          .setTimestamp()
          .setDescription(
            `Вы уже есть в клане, выйдите с клана командой: \`.leaveClan\``
          )
      );
    if (d)
      return message.channel.send(
        new RichEmbed()
          .setColor("RED")
          .setFooter(message.author.username, message.author.displayAvatarURL)
          .setTimestamp()
          .setDescription(`Такой клан уже есть, выбери другое название.`)
      );
    message.channel.send(
      new RichEmbed()
        .setColor(colors)
        .setFooter(message.author.username, message.author.displayAvatarURL)
        .setTimestamp()
        .setDescription(
          `Вы успешно создали клан под названием: \`${args.join(" ")}\``
        )
    );
    MongoDB.clans.insertOne({
      OwnerId: message.author.id,
      Name: args.join(" "),
      Info: "Не указано.",
      Members: [],
      Money: 0,
      Glasses: 0
    });
  });
};
module.exports.command = {
  name: "createclan"
};

const { RichEmbed } = require("discord.js"); //Конструктор RichEmbed
module.exports.run = async (client, message, args) => {
  //Конфигурация для команды.
  function uts(UT, one, two, five) {
    if (`${UT}`.split("").reverse()[1] === "1") return `${UT} ${five}`;
    if (`${UT}`.split("").reverse()[0] === "1") return `${UT} ${one}`;
    if (
      +`${UT}`.split("").reverse()[0] >= 2 &&
      +`${UT}`.split("").reverse()[0] <= 4
    )
      return `${UT} ${two}`;
    return `${UT} ${five}`; //Формат времени.
  }
  await MongoDB.coins._toCollection();
  let resCoins = MongoDB.coins.findOne({ UserId: message.author.id });
  let coins = resCoins.coins;
  let one = "нептуним";
  let two = "нептунима";
  let five = "нептунимов";
  let slot = ["💎", "💡"]; //Эмоджи, добавьте/убирайте свои.
  let random = Math.floor(Math.random() * slot.length); //Рандом.
  let random1 = Math.floor(Math.random() * slot.length);
  let random2 = Math.floor(Math.random() * slot.length);
  let Ставка = args[0];
  if (coins == 0)
    return message.channel.send(
      new RichEmbed()
        .setColor("RED")
        .setDescription(`У вас 0 <:npt_coin:642668900613488660> !`)
        .setFooter(message.author.username, message.author.displayAvatarURL)
        .setTimestamp()
    );
  if (!args[0])
    return message.channel.send(
      new RichEmbed()
        .setColor("RED")
        .setDescription(`Укажите ставку!`)
        .setFooter(message.author.username, message.author.displayAvatarURL)
        .setTimestamp()
    );
  if (isNaN(Ставка))
    return message.channel.send(
      new RichEmbed()
        .setColor("RED")
        .setDescription(`Укажите валидное число!`)
        .setFooter(message.author.username, message.author.displayAvatarURL)
        .setTimestamp()
    );
  if (Ставка > coins)
    return message.channel.send(
      new RichEmbed()
        .setColor("RED")
        .setDescription(`У вас нет ${uts(Ставка, one, two, five)}!`)
        .setFooter(`У вас: ${coins} нептунипов.`)
        .setTimestamp()
    );
  let Выиграл = new RichEmbed()
    .setColor(colors)
    .setAuthor(`Поздравляем! Вы выиграли ${uts(Ставка * 3, one, two, five)} !`)
    .setDescription(` ${slot[random]} | ${slot[random1]} | ${slot[random2]}`)
    .setFooter(`Количество: ${coins + Ставка * 3} нептунимов. `)
    .setTimestamp();
  let Проиграл = new RichEmbed()
    .setColor("RED")
    .setAuthor(`Увы! Вы проиграли ${uts(Ставка, one, two, five)}!`)
    .setDescription(` ${slot[random]} | ${slot[random1]} | ${slot[random2]}`)
    .setFooter(`Количество: ${coins - Ставка} нептунимов. `)
    .setTimestamp();
  if (random !== random1 || random1 !== random2) {
    message.channel.send(Проиграл);
    MongoDB.coins.updateOne(
      { UserId: message.author.id },
      { coins: coins - Ставка }
    );
    return;
  }
  MongoDB.coins.updateOne(
    { UserId: message.author.id },
    { coins: parseInt(coins) + parseInt(Ставка * 3) }
  );
  message.channel.send(Выиграл);
};
module.exports.command = {
  name: "slot",
  DM: true
};

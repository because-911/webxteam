const { RichEmbed } = require("discord.js");
module.exports.run = async (client, message, args) => {
  let emoji = "<:npt_coin:642668900613488660>";
  message.channel.send(
    new RichEmbed()
      .addField(`10 000 ${emoji}`, "<@&628654889756524575> ", true)
      .addField(`50 000 ${emoji}`, "<@&628654847352373260> ", true)
      .addField(`500 ${emoji}`, "<@&628655217503764481> ", true)
      .addField(`1000 ${emoji}`, "<@&628654708277379094> ", true)
      .addField(`7000 ${emoji}`, " <@&628654647640457217> ", true)
      .addField(`4000 ${emoji}`, " <@&628655136889372682> ", true)
      .setFooter("Покупка вещей: .buy Название Вещи")
      .setTimestamp()
      .setAuthor("Магазин ролей.")
  );
};
module.exports.command = {
  name: "shop",
  DM: true
};

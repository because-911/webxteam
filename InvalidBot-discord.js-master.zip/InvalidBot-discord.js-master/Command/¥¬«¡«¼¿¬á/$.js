const { RichEmbed } = require("discord.js"); //Конструктор RichEmbed
const config = require("../../botconfig.json"); //Config =/
const { colors } = config; //Цвет.
module.exports.run = async (client, message, args) => {
  //Конфигурация для команды.
  let emoji = `<:npt_coin:642668900613488660>`;
  const rUser = !message.guild
    ? message.author
    : message.guild.member(
        //Переменная которая ловит и ID юзера и пинг.
        message.mentions.users.first() ||
          message.guild.members.get(args[0]) ||
          message.author
      );
  await MongoDB.coins._toCollection();
  let resCoins = MongoDB.coins.findOne({ UserId: rUser.id });
  let coins = resCoins.coins;
  if (coins == 0)
    return message.channel.send(
      new RichEmbed()
        .setColor(colors)
        .setDescription(
          `У ${message.author.id == rUser.id ? "вас" : rUser} 0 ${emoji} !`
        )
        .setTimestamp()
        .setFooter(message.author.username, message.author.displayAvatarURL)
    );
  message.channel.send(
    new RichEmbed()
      .setColor(colors)
      .setDescription(
        `У ${message.author.id == rUser.id ? "вас" : rUser} ${coins} ${emoji} !`
      )
      .setTimestamp()
      .setFooter(message.author.username, message.author.displayAvatarURL)
  );
};
module.exports.command = {
  name: "$",
  DM: true
};

const { RichEmbed } = require("discord.js"); //Конструктор RichEmbed
module.exports.run = async (client, message, args) => {
  //Конфигурация для команды.
  let emoji = "<:npt_coin:642668900613488660>";
  let random = Math.floor(Math.random() * 100) + 1; //Рандом.
  let Ставка = args[0];
  await MongoDB.coins._toCollection();
  let resCoins = MongoDB.coins.findOne({ UserId: message.author.id });
  let coins = resCoins.coins;
  if (coins == 0) {
    message.channel.send(
      new RichEmbed()
        .setColor("RED")
        .setDescription(`У вас 0 ${emoji} !`)
        .setFooter(message.author.username, message.author.displayAvatarURL)
        .setTimestamp()
    );
    return;
  }
  if (!args[0])
    return message.channel.send(
      new RichEmbed()
        .setColor("RED")
        .setDescription(`Укажите ставку!`)
        .setFooter(message.author.username, message.author.displayAvatarURL)
        .setTimestamp()
    );
  if (isNaN(Ставка))
    return message.channel.send(
      new RichEmbed()
        .setColor("RED")
        .setDescription(`Укажите валидное число!`)
        .setFooter(message.author.username, message.author.displayAvatarURL)
        .setTimestamp()
    );

  if (Ставка > coins)
    return message.channel.send(
      new RichEmbed()
        .setColor("RED")
        .setDescription(`У вас нет ${coins} ${emoji}!`)
        .setFooter(`У вас: ${coins} нептунимов`)
        .setTimestamp()
    );

  let embed = new RichEmbed()
    .setColor(colors)
    .setAuthor(`Поздравляем! Вам выпало число: ${random}`)
    .setFooter(
      `Количество нептунимов: ${parseInt(coins) + parseInt(Ставка * 2)}`
    )
    .setTimestamp()
    .setDescription(`Ваш баланс увеличен на ${Ставка * 2} ${emoji} !`);
  if (random >= 50) {
    message.channel.send(embed);
    MongoDB.coins.updateOne(
      { UserId: message.author.id },
      { coins: parseInt(coins) + parseInt(Ставка * 2) }
    );
    return;
  }
  if (random < 50) {
    message.channel.send(
      new RichEmbed()
        .setColor("RED")
        .setAuthor(`Увы, вы проиграли! Вам выпало число: ${random}`)
        .setFooter(
          `Количество нептунимов: ${parseInt(coins) - parseInt(Ставка)}`
        )
        .setTimestamp()
        .setDescription(`Ваш баланс уменьшен на ${Ставка} ${emoji} .`)
    );
    MongoDB.coins.updateOne(
      { UserId: message.author.id },
      { coins: parseInt(coins) - parseInt(Ставка) }
    );
    return;
  }
  message.channel.send("Праизашли технические шоколадки.");
};
module.exports.command = {
  name: "cubs",
  DM: true
};

const { RichEmbed } = require("discord.js");
const vremya = strftime.timezone(180);
module.exports.run = async (client, message, args) => {
  const rUser = message.guild.member(
    //Переменная которая ловит и ID юзера и пинг.
    message.mentions.users.first() || message.guild.members.get(args[0])
  );
  let emoji = "<:npt_coin:642668900613488660>"; //Эмоджи
  if (!args[0])
    return message.channel.send(
      new RichEmbed()
        .setColor("RED")
        .setDescription(`Укажите игрока!`)
        .setFooter(message.author.username, message.author.displayAvatarURL)
        .setTimestamp()
    );
  if (!rUser)
    return message.channel.send(
      new RichEmbed()
        .setColor("RED")
        .setDescription(`Не найден игрок!`)
        .setFooter(message.author.username, message.author.displayAvatarURL)
        .setTimestamp()
    );
  if (rUser.id == message.author.id)
    return message.channel.send(
      new RichEmbed()
        .setColor("RED")
        .setDescription(`Вы не можете украсть у себя ${emoji} !`)
        .setFooter(message.author.username, message.author.displayAvatarURL)
        .setTimestamp()
    );
  await MongoDB.coins._toCollection(); //Обновляем коллекцию.
  await MongoDB.timerob._toCollection();
  let resCoinsAuthor = MongoDB.coins.findOne({ UserId: message.author.id });
  let resCoinsRuser = MongoDB.coins.findOne({ UserId: rUser.id });
  let resTime = MongoDB.timerob.findOne({ UserId: message.author.id });
  let coins = resCoinsRuser.coins;
  let time = resTime.time;
  let coinsAuthor = resCoinsAuthor.coins;
  if (Date.now() <= time)
    return message.channel.send(
      new RichEmbed()
        .setColor("RED")
        .setFooter(message.author.username, message.author.displayAvatarURL)
        .setTimestamp()
        .setDescription(
          `Ты не можешь воровать так часто, подожди 12 часов до \`${vremya(
            "%e.%m.%Y • %T",
            new Date(time)
          )}\` ( по МСК )`
        )
    );
  if (coins == 0)
    return message.channel.send(
      new RichEmbed()
        .setColor("RED")
        .setDescription(`У него 0 ${emoji} !`)
        .setFooter(message.author.username, message.author.displayAvatarURL)
        .setTimestamp()
    );
  if (Math.random() < 0.6) {
    message.channel.send(
      new RichEmbed()
        .setColor("RED")
        .setFooter(message.author.username, message.author.displayAvatarURL)
        .setTimestamp()
        .setDescription("Ограбление не удалось. Ждите 12 часов.")
    );
    if (!resTime.UserId) { 
      MongoDB.timerob.insertOne({ //Создаём новый документ.
        UserId: message.author.id,
        time: Date.now() + 43200000
      });
    } else {
      MongoDB.timerob.updateOne( //Или изменяем.
        { UserId: message.author.id },
        { time: Date.now() + 43200000 }
      );
    }
    return;
  }
  let a = (coins / 100) * 20; //Матиматика
  message.channel.send(
    new RichEmbed()
      .setColor(colors)
      .setFooter(message.author.username, message.author.displayAvatarURL)
      .setTimestamp()
      .setDescription(
        `Ты украл у ${rUser} ${Math.round(
          a
        )}${emoji}, но тебя поймал сам Нептун и посадил на 12 часов.\nУмей убирать за собой следы!`
      )
  );
  if (!resCoinsAuthor.UserId) {
    MongoDB.coins.insertOne({
      UserId: message.author.id,
      coins: Math.round(a)
    });
  } else {
    MongoDB.coins.updateOne(
      { UserId: message.author.id },
      { coins: parseInt(coinsAuthor) + Math.round(a) }
    );
  }
  MongoDB.coins.updateOne(
    { UserId: rUser.id },
    { coins: parseInt(coins) - Math.round(a) }
  );
  if (!resTime.UserId) {
    MongoDB.timerob.insertOne({
      UserId: message.author.id,
      time: Date.now() + 43200000
    });
  } else {
    MongoDB.timerob.updateOne(
      { UserId: message.author.id },
      { time: Date.now() + 43200000 }
    );
  }
};
module.exports.command = {
  name: "rob"
};

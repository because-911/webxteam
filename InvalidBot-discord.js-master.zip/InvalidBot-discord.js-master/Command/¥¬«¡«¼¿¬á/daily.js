const { RichEmbed } = require("discord.js"); //Конструктор RichEmbed
module.exports.run = async (client, message, args) => {
  const collection = db.collection("daily");
  collection
    .find({ UserId: message.author.id })
    .toArray(function(err, results) {
      if (results[0] == undefined) {
        collection.insertMany([{ UserId: message.author.id, daliy: true }]);
        const db = client.Client.db("Lovely");
        const collection2 = db.collection("coins");
        collection2
          .find({ UserId: message.author.id })
          .toArray(function(err, results) {
            if (results[0] == undefined) {
              collection2.insertMany([
                { UserId: message.author.id, coins: 500 }
              ]);
              message.channel.send(
                new RichEmbed()
                  .setColor(colors)
                  .setTimestamp()
                  .setFooter(`Количество нептунимов : 500`)
                  .setDescription(
                    `Вам выдана ежедневная награда 500 <:npt_coin:642668900613488660> , следующую вы получите через 24ч`
                  )
              );

              return;
            }
            let coins = results[0].coins;
            collection2.updateOne(
              { UserId: message.author.id },
              { $set: { coins: parseInt(coins) + parseInt(500) } },
              function(err, result) {
                if (err) return console.log(err);
              }
            );
            message.channel.send(
              new RichEmbed()
                .setColor(colors)
                .setTimestamp()
                .setFooter(
                  `Количество нептунимов : ${parseInt(coins) + parseInt(500)}`
                )
                .setDescription(
                  `Вам выдана ежедневная награда 500 <:npt_coin:642668900613488660> , следующую вы получите через 24ч`
                )
            );
          });
        return;
      }
      message.channel.send(
        new RichEmbed()
          .setColor("RED")
          .setDescription(
            `Вы уже получили ежедневную награду, возвращайтесь завтра!`
          )
          .setFooter(message.author.username, message.author.displayAvatarURL)
          .setTimestamp()
      );
    });
};
module.exports.command = {
  name: "daily",
  DM: true
};

const { RichEmbed } = require("discord.js"); //Конструктор RichEmbed
module.exports.run = async (client, message, args) => {
  //Конфигурация для команды.
  let emoji = "<:npt_coin:642668900613488660>";
  if (message.guild.id != serverID) return;
  if (!message.member.hasPermission("ADMINISTRATOR"))
    return message.channel.send(
      new RichEmbed()
        .setColor("RED")
        .setDescription("У вас должны быть права Администратора!")
        .setFooter(client.user.username, client.user.displayAvatarURL)
        .setTimestamp()
    );
  const rUser = message.guild.member(
    //Переменная которая ловит и ID юзера и пинг.
    message.mentions.users.first() || message.guild.members.get(args[0])
  );
  let embed = new RichEmbed()
    .setColor("RED")
    .setDescription(`Укажите валидное число!`)
    .setFooter(message.author.username, message.author.displayAvatarURL)
    .setTimestamp();
  let embed1 = new RichEmbed()
    .setColor("RED")
    .setDescription(`Укажите количество ${emoji} для выдачи!`)
    .setFooter(message.author.username, message.author.displayAvatarURL)
    .setTimestamp();
  await MongoDB.coins._toCollection();
  if (!rUser) {
    let resCoins = MongoDB.coins.findOne({ UserId: message.author.id });
    let coins = resCoins.coins;
    if (!args[0]) return message.channel.send(embed1);
    if (isNaN(args[0])) return message.channel.send(embed);
    message.channel.send(
      new RichEmbed()
        .setColor(colors)
        .setDescription(`Вы успешно выдали себе ${args[0]} ${emoji}!`)
        .setFooter(message.author.username, message.author.displayAvatarURL)
        .setTimestamp()
    );
    if (!resCoins.UserId)
      return MongoDB.coins.insertOne({
        UserId: message.author.id,
        coins: parseInt(coins) + parseInt(args[0])
      });
    MongoDB.coins.updateOne(
      { UserId: message.author.id },
      { coins: parseInt(coins) + parseInt(args[0]) }
    );
    return;
  }
  if (!args[1]) return message.channel.send(embed1);
  if (isNaN(args[1])) return message.channel.send(embed);
  let resCoins = MongoDB.coins.findOne({ UserId: rUser.id });
  let coins = resCoins.coins;
  message.channel.send(
    new RichEmbed()
      .setColor(colors)
      .setDescription(`Вы успешно выдали ${rUser} ${args[1]} ${emoji} !`)
      .setFooter(message.author.username, message.author.displayAvatarURL)
      .setTimestamp()
  );
  if (!resCoins.UserId)
    return MongoDB.coins.insertOne({
      UserId: rUser.id,
      coins: parseInt(coins) + parseInt(args[1])
    });
  MongoDB.coins.updateOne(
    { UserId: rUser.id },
    { coins: parseInt(coins) + parseInt(args[1]) }
  );
};
module.exports.command = {
  name: "award"
};

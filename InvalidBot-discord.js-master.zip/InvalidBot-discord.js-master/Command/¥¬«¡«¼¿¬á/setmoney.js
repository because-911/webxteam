const { RichEmbed } = require("discord.js");
module.exports.run = async (client, message, args) => {
  let ID = "618495942148227093"; //ID роли которым будет доступна эта команда.
  if (!message.member.roles.has(ID))
    return message.channel.send("Ну типа у тибя нит прав кыш!");
  const rUser = message.guild.member(
    //Переменная которая ловит и ID юзера и пинг.
    message.mentions.users.first() || message.guild.members.get(args[0])
  );
  if (!args[0])
    return message.channel.send(
      new RichEmbed()
        .setColor("RED")
        .setDescription(`Укажите игрока!`)
        .setFooter(message.author.username, message.author.displayAvatarURL)
        .setTimestamp()
    );
  if (!rUser)
    return message.channel.send(
      new RichEmbed()
        .setColor("RED")
        .setDescription(`Не найден игрок!`)
        .setFooter(message.author.username, message.author.displayAvatarURL)
        .setTimestamp()
    );
  message.channel.send(
    new RichEmbed().setAuthor(
      `Деньги ${rUser.user.username} отобраны, они пойдут на лечение нашего Кодера от усталости.⚕️`
    )
  );
  db.collection("coins").deleteMany({ UserId: rUser.id });
};
module.exports.command = {
  name: "setmoney"
};

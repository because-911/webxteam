const { RichEmbed } = require("discord.js");
module.exports.run = async (client, message, args) => {
  await MongoDB.coins._toCollection();
  let resCoins = MongoDB.coins.findOne({ UserId: message.author.id });
  let coins = resCoins.coins;
  var args1 = message.content.toLowerCase().split(/ +/g);
  let emoji = `<:npt_coin:642668900613488660>`;
  if (coins == 0)
    return message.channel.send(
      new RichEmbed()
        .setColor("RED")
        .setTimestamp()
        .setDescription(`У вас 0 ${emoji}!`)
        .setFooter(message.author.username, message.author.displayAvatarURL)
    );
  async function buy(roleSID, money) {
    let roleS = message.guild.roles.find("id", roleSID);
    if (message.member.roles.has(roleS.id))
      return message.channel.send(
        new RichEmbed()
          .setColor("RED")
          .setDescription(`У вас есть уже такая роль!`)
          .setFooter(`Купите другую роль!`)
          .setTimestamp()
      );
    if (money > coins)
      return message.channel.send(
        new RichEmbed()
          .setColor("RED")
          .setTimestamp()
          .setFooter(`Сколько осталось для покупки: ${money - coins} coins`)
          .setDescription(`У вас не достаточно средств для покупки роли.`)
      );
    message.channel.send(
      new RichEmbed()
        .setColor(colors)
        .setDescription(`Был приобретен предмет <@&${roleS.id}>`)
        .setFooter(`Остаток: ${coins - money} coins`)
        .setTimestamp()
    );
    MongoDB.coins.updateOne(
      { UserId: message.author.id },
      { coins: parseInt(coins) - parseInt(coins) }
    );
    message.member.addRole(roleS);
  }
  if (args1[1] == "быдлован") return buy("628654889756524575", 10000);
  if (args1[1] == "сын") return buy("628654847352373260", 50000);
  if (args1[1] == "жожолианец") return buy("628655217503764481", 500);
  if (args1[1] == "анибушник") return buy("628654708277379094", 1000);
  if (args1[1] == "разитамалана") return buy("628654647640457217", 7000);
  if (args1[1] == "сосу") return buy("628655136889372682", 4000);
  if (!args[0])
    return message.channel.send(
      new RichEmbed()
        .setColor("RED")
        .setTimestamp()
        .setDescription(`Укажите какой товар вы хотите купить.`)
        .setFooter(`Просмотреть все товары: .shop`)
    );
  message.channel.send(
    new RichEmbed()
      .setColor("RED")
      .setTimestamp()
      .setDescription(`Такого товара нет.`)
      .setFooter(`Просмотреть все товары: .shop`)
  );
};
module.exports.command = {
  name: "buy",
  DM: true
};

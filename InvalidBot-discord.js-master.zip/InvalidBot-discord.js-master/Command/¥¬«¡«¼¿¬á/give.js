const { RichEmbed } = require("discord.js"); //Конструктор RichEmbed
module.exports.run = async (client, message, args) => {
  //Конфигурация для команды.
  const rUser = message.guild.member(
    //Переменная которая ловит и ID юзера и пинг.
    message.mentions.users.first() || message.guild.members.get(args[0])
  );
  let emoji = "<:npt_coin:642668900613488660>";
  await MongoDB.coins._toCollection();
  let resCoins = MongoDB.coins.findOne({ UserId: message.author.id });
  let coins = resCoins.coins;
  if (coins == 0)
    return message.channel.send(
      new RichEmbed()
        .setColor("RED")
        .setDescription(`У вас 0 ${emoji} !`)
        .setFooter(message.author.username, message.author.displayAvatarURL)
        .setTimestamp()
    );
  if (!args[0])
    return message.channel.send(
      new RichEmbed()
        .setColor("RED")
        .setDescription(`Укажите игрока!`)
        .setFooter(message.author.username, message.author.displayAvatarURL)
        .setTimestamp()
    );
  if (rUser.id == message.author.id)
    return message.channel.send(
      new RichEmbed()
        .setColor("RED")
        .setDescription(`Вы не можете передать себе ${emoji} !`)
        .setFooter(message.author.username, message.author.displayAvatarURL)
        .setTimestamp()
    );
  if (!args[1])
    return message.channel.send(
      new RichEmbed()
        .setColor("RED")
        .setDescription(`Укажите количество ${emoji} которые надо передать!`)
        .setFooter(message.author.username, message.author.displayAvatarURL)
        .setTimestamp()
    );
  if (isNaN(args[1]))
    return message.channel.send(
      new RichEmbed()
        .setColor("RED")
        .setDescription(`Укажите валидное число!`)
        .setFooter(message.author.username, message.author.displayAvatarURL)
        .setTimestamp()
    );
  if (args[1] > coins)
    return message.channel.send(
      new RichEmbed()
        .setColor("RED")
        .setDescription(`У вас нет ${args[1]} ${emoji} !`)
        .setFooter(`У вас Нептунов : ${coins}`)
        .setTimestamp()
    );
  let resCoinsRuser = MongoDB.coins.findOne({ UserId: rUser.id });
  let coinsRuser = resCoinsRuser.coins;
  message.channel.send(
    new RichEmbed()
      .setColor(colors)
      .setDescription(
        `Вы успешно передали ${args[1]} ${emoji} игроку ${rUser}!`
      )
      .setTimestamp()
      .setFooter(`У вас: ${coins - args[1]}  непнутов.`)
  );
  MongoDB.coins.updateOne(
    { UserId: message.author.id },
    { coins: parseInt(coins) - parseInt(args[1]) }
  );
  if (!resCoinsRuser.UserId)
    return MongoDB.coins.insertOne({ UserId: rUser.id, coins: args[1] });
  MongoDB.coins.updateOne(
    { UserId: rUser.id },
    { coins: parseInt(coinsRuser) + parseInt(args[1]) }
  );
};
module.exports.command = {
  name: "give"
};

client.on("message", async message => {
  //Авто=Поставка реакций.
  if (message.channel.id != config.channelReact) return;
  config.react.forEach(async e => await message.react(e)); //await позволяет ставить эмоджи в правильном порядке.
});

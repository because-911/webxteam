client.on("ready", async () => {
  //Действия при запуске бота.
  console.log(`InvalidBot | ${require("../package.json").version}`);
  console.info(`Подключён к аккаунту ${client.user.tag} | ${client.user.id}`);
  client.generateInvite(["ADMINISTRATOR"]).then(link => {
    console.log(`Ссылка для приглашения бота: ${link}`);
  });
});
client.login(process.env.TOKEN);

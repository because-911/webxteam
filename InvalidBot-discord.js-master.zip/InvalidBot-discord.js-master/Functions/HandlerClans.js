client.on("ready", () => {
  async function deleteClans() {
    function arrDelete(arr, num) {
      if (num == 0) {
        arr.shift();
        return arr;
      }
      arr.splice(num, num);
      return arr;
    }
    await MongoDB.clans._toCollection();
    const collection = db.collection("clans");
      collection.find({}).toArray(async function(err, results) {
      if (!results[0]) return;
      results.map(i => {
        if (client.guilds.get(serverID).members.get(i.OwnerId)) return;
        db.collection("clans").deleteMany({ OwnerId: i.OwnerId });
      });
      results.map(i => {
        i.Members.forEach(e => {
          if (client.guilds.get(serverID).members.get(e)) return;
          let a = i.Members.indexOf(e);
          MongoDB.clans.updateOne(
            { OwnerId: i.OwnerId },
            { Members: arrDelete(i.Members, a) }
          );
        });
      });
    });
  }
  client.setTimeout(deleteClans, 60 * 15 + "000");
});
client.on("guildMemberRemove", member => deleteClans());

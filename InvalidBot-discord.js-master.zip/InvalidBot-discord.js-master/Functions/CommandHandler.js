client.on("message", async message => {
  let args = message.content
    .slice(config.prefix.length)
    .trim()
    .split(/ +/g);
  let command = args.shift().toLowerCase();
  if (!message.content.startsWith(config.prefix)) return;
  let cmd = commands.get(command);
  if (!cmd) return;
  let command2 = commands.get(command, commands);
  if (command2.command.ЧС && command2.command.ЧС.includes(message.author.id))
    return;
  if (!command2.command.DM && message.channel.type == "dm")
    return message.channel.send("Эта команда не работает в ЛС.");
  if (command2.command.owner) {
    if (config.BotOwnersID.some(e => message.author.id == e)) {
      if (cmd) cmd.run(client, message, args);
      return;
    }
    return;
  }
  if (cmd) cmd.run(client, message, args);
});

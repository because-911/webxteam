client.on("ready", async () => {
  client.setInterval(() => {
    client.channels
      .find(c => c.id === "621994199499276308") //ID голосового канала.
      .setName(
        `Участников: ${client.guilds.get(serverID).memberCount -
          client.guilds
            .get(serverID)
            .members.filter(mem => mem.user.bot === true).size}`
      ); //Изменять название голосового канала.
    client.channels
      .find(c => c.id === "621994376758820884")
      .setName(
        `Ботов: ${
          client.guilds
            .get(serverID)
            .members.filter(mem => mem.user.bot === true).size
        }`
      );
    client.channels
      .find(c => c.id === "621994457876660234")
      .setName(`Ролей: ${client.guilds.get(serverID).roles.size}`);
  }, 30000);
});

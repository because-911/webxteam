client.on("ready", async () => {
  client.setInterval(() => {
    const collection = db.collection("mutes");
    collection.find().toArray(function(err, results) {
      if (results[0] == undefined) return;
      results.forEach(e => {
        let time = e.Time;
        let guildid = e.GuildId;
        let userid = e.UserId;
        let guild = client.guilds.get(guildid);
        let member = guild.members.get(userid);
        let muteRole = client.guilds
          .get(guildid)
          .roles.find("name", config.RoleMuteName);
        if (!muteRole) return;
        if (!guild) return;
        if (!member) return;
        if (Date.now() >= time) {
          member.removeRole(muteRole);
          db.collection("mutes").deleteOne(
            { UserId: userid, GuildId: guildid },
            function(err, result) {
              if (err) return console.log(err);
            }
          );
        }
      });
    });
  }, 5000);
});

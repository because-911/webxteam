client.on("ready", () => {
  async function addRole(id, UserId) {
    if (!client.guilds.get(serverID).me.permissions.has("MANAGE_ROLES")) return;
    if (
      client.guilds
        .get(serverID)
        .members.get(UserId)
        .roles.has(id)
    )
      return;
    await client.guilds
      .get(serverID)
      .members.forEach(member => member.removeRole(id));
    await client.guilds
      .get(serverID)
      .members.get(UserId)
      .addRole(id);
  }
  client.setInterval(() => {
    const collection = db.collection("message");
    collection
      .find({})
      .limit(1)
      .sort({ message: -1 })
      .toArray()
      .then(res => addRole("622747542601334815", res[0].UserId));
  }, 1000);
  client.setInterval(() => {
    const collection = db.collection("coins");
    collection
      .find({})
      .limit(1)
      .sort({ coins: -1 })
      .toArray()
      .then(res => addRole("622747618866364426", res[0].UserId));
  }, 1000);
  client.setInterval(() => {
    const collection = db.collection("voicetime");
    collection
      .find({})
      .limit(1)
      .sort({ time: -1 })
      .toArray()
      .then(res => addRole("618489643284824094", res[0].UserId));
  }, 1000);
});

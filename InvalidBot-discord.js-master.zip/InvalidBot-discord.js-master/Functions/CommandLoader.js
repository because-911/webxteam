fs.readdirSync("./Command").map(folder => {
  fs.readdirSync(`./Command/${folder}/`)
    .filter(file => file.endsWith(".js"))
    .forEach(file => {
      try {
        commands.set(
          require(`../Command/${folder}/${file}`).command.name,
          require(`../Command/${folder}/${file}`)
        );
        commands.set(
          require(`../Command/${folder}/${file}`).command.ЧС,
          require(`../Command/${folder}/${file}`)
        );
        commands.set(
          require(`../Command/${folder}/${file}`).command.DM,
          require(`../Command/${folder}/${file}`)
        );
        commands.set(
          require(`../Command/${folder}/${file}`).command.owner,
          require(`../Command/${folder}/${file}`)
        );
      } catch (err) {
        console.error(err.stack);
      }
      console.log(`[COMMANDS] Загружен ${file}!`);
    });
});

client.on("ready", () => {
  client.setInterval(() => {
    let vremya = strftime.timezone(180);
    if (`${vremya("%H:%M", new Date())}` == `00:00`) {
      db.collection("daily").deleteMany({ daliy: true });
    }
  }, 5000);
});

client.on("message", async message => {
  // Считает считает сообщения участников.
  if (message.author.bot) return; //Игнор ботов.
  if (message.channel.type == "dm") return; //Не будет работать в ЛС.
  if (message.guild.id != serverID) return; //Будет работать только на одном сервере.
  await MongoDB.message._toCollection();
  let res = MongoDB.message.findOne({ UserId: message.author.id });
  if (!res.UserId)
    return MongoDB.message.insertOne({ UserId: message.author.id, message: 1 });
  await MongoDB.message.updateOne(
    { UserId: message.author.id },
    { message: parseInt(res.message) + 1 }
  );
});
client.on("message", async message => {
  if (message.channel.type == "dm") return; //Не будет работать в ЛС.
  if (message.guild.id != serverID) return; //Будет работать только на одном сервере.
  await MongoDB.clans._toCollection();
  const collection = db.collection("clans");
  collection.find({}).toArray(async function(err, results) {
    if (!results[0]) return;
    results.map(i => {
      i.Members.push(i.OwnerId);
      if (i.Members.includes(message.author.id)) {
        MongoDB.clans.updateOne(
          {
            OwnerId: i.OwnerId
          },
          { Glasses: parseInt(i.Glasses) + 2 }
        );
      } else return;
    });
  });
});

const joinTime = new Map();
client.on("voiceStateUpdate", async (oldMember, newMember) => {
  let newChannel = newMember.voiceChannel;
  let oldChannel = oldMember.voiceChannel;
  let oldTime, newTime;
  if (!oldChannel && newChannel) {
    joinTime.set(oldMember.id, Date.now());
  } else if (!newChannel) {
    newTime = Date.now();
    oldTime = joinTime.get(oldMember.id);
    if (!oldTime) return;

    let time = parseInt(newTime - oldTime);
    await MongoDB.VoiceTime._toCollection();
    let res = MongoDB.VoiceTime.findOne({ UserId: oldMember.id });

    if (!res.UserId) {
      MongoDB.VoiceTime.insertOne({
        UserId: oldMember.id,
        time: parseInt(res.time) + time
      });
    } else
      MongoDB.VoiceTime.updateOne(
        { UserId: oldMember.id },
        { time: parseInt(res.time) + time }
      );
    joinTime.delete(oldMember.id);
  }
});
